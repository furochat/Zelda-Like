<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="spritesheet" tilewidth="64" tileheight="64" tilecount="9" columns="3">
 <image source="../spritesheet.png" width="192" height="192"/>
 <tile id="4">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="40">
    <polygon points="0,0 20,-36 42,-2 40,1 36,5 28,5 27,8 16,8 13,3 9,5"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="5">
  <objectgroup draworder="index" id="2">
   <object id="1" x="39" y="48">
    <polygon points="0,0 -14,0 -15,-4 -22,-3 -27,-7 -27,-11 -11,-40 -8,-43 -5,-43 -2,-40 4,-28 9,-19 13,-11 13,-7 8,-3 4,-3 3,-4 1,-4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="6">
  <objectgroup draworder="index" id="2">
   <object id="1" x="11" y="45">
    <polygon points="0,0 0,-5 2,-10 11,-19 16,-23 19,-24 30,-24 33,-20 35,-19 36,-17 37,-14 40,-14 43,-12 45,-8 46,-5 46,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="7">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0">
    <polygon points="0,0 64,0 64,64 0,64"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
